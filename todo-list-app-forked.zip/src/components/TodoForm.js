import React, { useState, useEffect } from "react";

const TodoForm = (props) => {
  const [input, setInput] = useState("");

  //props.edit ? props.edit.value : ""
  useEffect(() => {
    //props.edit ? props.edit.value : '';
    if (props.value) {
      setInput(props.edit.value);
    } else {
      setInput("");
    }
  }, []);

  const handleChange = (e) => {
    setInput(e.target.value);
  };

  const submitHandler = (e) => {
    e.preventDefault();

    props.onSubmit({
      id: Math.floor(Math.random() * 10000),
      text: input
      //isCompleted: false
    });
    setInput("");
  };

  return (
    <form className="todo-form" onSubmit={submitHandler}>
      {props.edit ? (
        <>
          <input
            type="text"
            name="text"
            placeholder="Update your item"
            className="todo-input"
            value={input}
            onChange={handleChange}
          />
          <button className="todo-button">Update</button>
        </>
      ) : (
        <>
          <input
            type="text"
            name="text"
            placeholder="Add a todo"
            className="todo-input"
            value={input}
            onChange={handleChange}
          />
          <button className="todo-button">Add todo</button>
        </>
      )}
    </form>
  );
};

export default TodoForm;
